import React, {Component} from 'react'

class ShopDetail extends Component {
    render() {
        return (
          <div class="shop-details">
            <h1 class="title">Shop Details</h1>
            <br />
            <table class="shop-table">
              <tr>
                <td>Shop Name</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Shop Owner</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Contact no.</td>
                <td>nil</td>
              </tr>
              <tr></tr>
              <tr>
                <td>S.C.O. No.</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Location</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Zip Code</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Timing</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Off-day</td>
                <td>nil</td>
              </tr>
            </table>
          </div>
        );
    }
}

export default ShopDetail