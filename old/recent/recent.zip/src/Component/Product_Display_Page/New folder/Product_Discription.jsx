import React, {Component} from 'react'

class ProductDetail extends Component {
    render() {
        return (
          <div class="product-details">
            <h1 class="title">Product Details</h1><br />
            <table class="product-table">
              <tr>
                <td>Type</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Color</td>
                <td>nil</td>
              </tr>
              <tr></tr>
              <tr>
                <td>Size</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Pattern</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Sleeve</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Fit</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Fabric</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Sales Package</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Pack of</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Ideal For</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Suitable For</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Fabric Care</td>
                <td>nil</td>
              </tr>
              <tr>
                <td>Reversible</td>
                <td>nil</td>
              </tr>
            </table>
          </div>
        );
    }
}

export default ProductDetail