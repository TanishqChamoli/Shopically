import React from "react";
import Checkout from './Checkout';

class CheckoutPage extends React.Component {
	render() {
		return (
			<Checkout/>
		);
	}
}

export default CheckoutPage;