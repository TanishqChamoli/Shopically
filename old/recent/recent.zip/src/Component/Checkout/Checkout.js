import React from 'react';
import { withRouter } from 'react-router-dom';
import axios from 'axios';

class Checkout extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            username:'',useraddress:'',userpincode:'',useremail:'',usermobile:''
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleChange(event) {
        this.setState({ [event.target.name]: event.target.value });
    }
    handleSubmit(event){
        alert("Order Placed");
        /*const phpurl = "http://localhost:80/shopically/my-app/backend/orderplaced.php";
        axios.post(phpurl, "uid=" + sessionStorage.getItem("uid"))
            .then(response => {
                this.setState({
                    username: response.data["user_name"],
                    useraddress: response.data["address"],
                    userpincode: response.data["pincode"],
                    useremail: response.data["email"],
                    usermobile: response.data["mobile"],
                })
            })
            .catch(error => {
                console.log(error);
            });*/
        event.preventDefault();
    }
    componentDidMount() {
        const phpurl = "http://localhost:80/shopically/my-app/backend/checkout.php";
        axios.post(phpurl,"uid="+sessionStorage.getItem("uid"))
            .then(response => {
                this.setState({
                    username: response.data["user_name"],
                    useraddress: response.data["address"],
                    userpincode: response.data["pincode"],
                    useremail: response.data["email"],
                    usermobile: response.data["mobile"],
                })
            })
            .catch(error => {
                console.log(error);
            });
    }
    render() {
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <input type="text" name="useraddress" value={this.state.useraddress} onChange={this.handleChange} />
                    <input type="text" name="userpincode" value={this.state.userpincode} onChange={this.handleChange} />
                    <input type="text" name="usermobile" value={this.state.usermobile} onChange={this.handleChange} />
                    <input type="text" name="useremail" value={this.state.useremail} onChange={this.handleChange} />
                    <input type="submit" value="Confirm" /><br />
                </form>
            </div>
        );
    }
}
export default withRouter(Checkout);