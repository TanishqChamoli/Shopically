import React,{Component} from "react";
import "bootstrap/dist/css/bootstrap.css";
import Final from "./productFinal";

class Checked extends Component {
render() {
	return (
		<div>
			<Final />
		</div>
	)
	}
}

export default Checked;