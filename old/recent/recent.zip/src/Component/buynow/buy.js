import React,{Component} from 'react'
import Buynow from './buynow'

class BuyDetail extends Component {
    render(){
        return(
            <Buynow />
        )
    }
}
export default BuyDetail;