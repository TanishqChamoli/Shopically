import React from 'react';
import './ShopDisplay.css';
const Random=()=>{
    return (
        <div ClassName = "Random">
        <button type="button" className="btn btn-primary">Random</button>
     </div>
    );
}
export default  Random;