import React from 'react';
const product_button=()=>{
    return (
        <button type="button" className="btn btn-primary flex-item btn-tag">Product</button>
    );
}
export default  product_button;
