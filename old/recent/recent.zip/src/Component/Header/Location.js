import React from 'react';
import './Header.css'
const location=()=>{
    return(
        <a  className="navbar-brand" href="#">Location</a>
    );
}
export default location;