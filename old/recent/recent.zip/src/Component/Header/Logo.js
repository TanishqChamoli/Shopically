import React from 'react';
import './Header.css'
const logo=()=>{
    return (
        <a className="navbar-brand " href="#">Shopically</a>
    );
}
export default logo;