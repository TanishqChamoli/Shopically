<?php
session_start();
$_SESSION["id"] = 1;
