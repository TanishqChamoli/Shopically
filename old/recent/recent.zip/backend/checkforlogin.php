<?php
   require_once ("dbconnection.php");
    try {
        session_start();
        if($_SESSION["uid"]===null){
            echo "UserNotLoggedIn";
        }
        else{
            echo "UserLoggedIn";
        }
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
?>