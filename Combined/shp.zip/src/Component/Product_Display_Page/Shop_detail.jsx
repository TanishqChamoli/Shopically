import React, {Component} from 'react'

class ShopDetail extends Component {
    render() {
        return (
            <div>
                <p>All the details of the shop will be displayed in this section</p>
            </div>
        )
    }
}

export default ShopDetail