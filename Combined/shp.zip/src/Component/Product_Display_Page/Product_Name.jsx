import React, {Component} from 'react';

class ProductName extends Component {
    render() {
        return (
            <div className="prdt_sum">
                <p id="prdt_name">Product Name</p>
                <p id="prdt_size">Size - XL</p>
                <button>Buy now</button>
                <button>Add to Cart</button>
            </div>
        )
    }
}

export default ProductName;