import React, {Component} from 'react'

class ProductDetail extends Component {
    render() {
        return (
            <div>
                <p>All kinds of details will be added here depending upon the form that we make in the seller section to fill the product details.</p>
            </div>
        )
    }
}

export default ProductDetail