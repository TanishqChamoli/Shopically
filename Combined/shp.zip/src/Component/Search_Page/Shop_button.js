import React from 'react';
const shop_button=()=>{
    return (
        <button type="button" className="btn btn-success flex-item-last2 btn-tag">Shop</button>
    );
}
export default  shop_button;
