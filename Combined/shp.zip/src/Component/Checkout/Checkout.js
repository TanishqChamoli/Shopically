import React,{Component} from "react";
import "bootstrap/dist/css/bootstrap.css";
import Checkout from "./checkout";
import Final from "./productFinal";

class Checked extends Component {
render() {
	return (
		<div>
		<Checkout />
		<Final />
		</div>
	)
	}
}

export default Checked;
