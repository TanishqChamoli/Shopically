import React from 'react';
import './Main.css';
const Random=()=>{
    return (
        <div ClassName = "Random">
        <button type="button" className="btn btn-primary flex-item">Random</button>
     </div>
    );
}
export default  Random;