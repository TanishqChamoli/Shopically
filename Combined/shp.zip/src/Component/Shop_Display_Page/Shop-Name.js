import React from 'react';
import './Main.css';
const ShopName = () =>{
    return (
        <div class="jumbotron jumbotron-fluid">
  <div class="containers">
    <div className="shop-detail">
      <h1 class="display-4">Shop Name</h1>
      <p class="lead">RATING  - *****</p>
      <p class = "lead">This shop deals with every type of clothes</p>
    </div>
    <img src="logo512.png" className="shopImg"  />
  </div>
  
</div>
    );
}
export default ShopName;