import React from 'react';
import './Main.css';
const sidebar=()=>{
    return (
        <aside className="aside">
            <h1>Filters</h1>
        </aside>
    );
}

export default sidebar;