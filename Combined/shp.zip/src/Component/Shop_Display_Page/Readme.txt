The comments are added in the main.js file
do not use the random function button now 
we will add that function later
