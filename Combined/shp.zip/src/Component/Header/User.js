import React from 'react';
import './Header.css'
const user=()=>{
    return (
        <a className="navbar-brand" href="#">User</a>
    );
}
export default user;